# OP3. Kata : Tablero de Ajedrez

## Descripción rápida 📋
Crear un tablero de ajedrez mediante bucles y los arrays de datos necesarios, como se muestra en la captura ajedrez.png
