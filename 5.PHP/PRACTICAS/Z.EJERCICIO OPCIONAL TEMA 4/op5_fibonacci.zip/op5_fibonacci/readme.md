# OP5. Kata : Fibonacci 

## Descripción rápida 📋
Obtener los números de la secuencia de Fibonacci a partir de un bucle.
La secuencia de Fibonacci es aquella en la que cualquier número es el resultado de la suma de los dos anteriores:

1 1 2 3 5 8 13 21 34 55 89 144 233


Crear una variable que determine el número de elementos que saque la secuencia.