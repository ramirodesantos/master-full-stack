# OP1 : Tabla de 100 números

## Descripción rápida 📋
Html con filas y columnas: 10 filas x 10 columnas

## Enunciado 📒

1. Maquetar 10 filas por 10 columnas con los números dentro
2. Cada columna que muestre un número del 1 al 100 (en orden ascendente)
3. Sustituir por una estructura de fors encadenados