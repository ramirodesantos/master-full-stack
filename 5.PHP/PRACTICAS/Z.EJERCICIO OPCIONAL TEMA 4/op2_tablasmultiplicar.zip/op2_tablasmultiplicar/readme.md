# OP2. Kata : Tablas de multiplicar 

## Descripción rápida 📋
Hacer 10 tablas donde se muestren las tablas de multiplicar.
Mediante Fors, conseguir una estructura parecida a la imagen tablas_multiplicar.png

No se da la maquetación. Hacer primero el HTML y CSS y después
