# OP4. Kata : Numero primo

## Descripción rápida 📋
Realizar una función que determine si un número (pasado por parámetro es primo o no)


## ¿Qué es un número primo?
Solo se pueden dividir entre 1 y ellos mismos. Ejemplos: 1, 2, 3, 5, 7, 11.
